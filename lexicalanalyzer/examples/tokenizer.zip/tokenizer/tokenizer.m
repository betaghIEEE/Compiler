#import <Foundation/Foundation.h>
#import "lexical.h"
#import "symbols.h"
#import "symbolTable.h"
#import "codeSource.h"


int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    // insert code here...
    NSLog(@"Hello, World!  Beginning Compilation");
	lexical *lexAnalyzer;
	symbolTable *st;
	codeSource *myFile;  
//	NSSet *reservedWords;
	myFile  = [[codeSource alloc] initWithFileName:
			@"/Volumes/tiger/home/dabeatty/test.txt"];
	st = [[ symbolTable alloc] init];
	lexAnalyzer = [[lexical alloc] initWithCodeSource: myFile
					symbolTable:st
					];
 
	[lexAnalyzer lex];
	//NSLog ( [lexAnalyzer nextTokenName]);
	NSLog ( @"Token identifier %d", [lexAnalyzer nextToken] );
	while ( [lexAnalyzer nextToken] != 0 ) 
	{
		[lexAnalyzer lex];
		//NSLog ( [lexAnalyzer nextTokenName]);
		NSLog ( @"Token identifier %d", [lexAnalyzer nextToken] );
	}
    [pool release];
    return 0;
}

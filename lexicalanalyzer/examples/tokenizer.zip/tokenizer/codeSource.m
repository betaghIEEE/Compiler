//
//  codeSource.m
//  tokenizer
//
//  Created by Daniel Beatty on 1/26/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "codeSource.h"


@implementation codeSource



-(void) setStartOfToken:(int) value
{
	startOfToken = value;
}

-(int) startOfToken
{
	return startOfToken;
}

-(void) setCurrentPosition:(int) value
{
	currentPosition = value;
}
  
-(int) currentPosition
{
	return currentPosition;
}

-(char) getCurrentCharacter
{
	char currentCharacter;
	currentCharacter = blocks[currentPosition];
	return currentCharacter;
}

-(void) nextCharacter
{
	currentPosition++;
}

-(NSString *) getString
{
	int lastCharacter = currentPosition - 1;
	int length = lastCharacter - startOfToken;
	unichar *blockPointer = blocks + startOfToken;
	NSString *aString = [[NSString alloc] 
					initWithCharacters:blockPointer
									length: length];
	
	return [aString autorelease];
	
}

-(BOOL) endOfBlock
{
	if ( currentPosition >= [block length] )
		return YES;
	return NO;
}


-(codeSource *) initWithFileName:(NSString *) fileName
{
	NS_DURING
	block = [NSData alloc];
	[block initWithContentsOfFile:fileName];
	blocks = [block bytes];
	NS_HANDLER
	NSLog (@"Some thing failed to get the block");
	exit(5);
	NS_ENDHANDLER
	return self;
}

-(codeSource *) initWithNSData:(NSData *) fileBlock
{
	block = fileBlock;
	[block retain];
//	blocks = [block bytes];
	return self;
}

@end

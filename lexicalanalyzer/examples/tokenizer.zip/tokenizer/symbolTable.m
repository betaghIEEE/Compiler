//
//  symbolTable.m
//  tokenizer
//
//  Created by Daniel Beatty on 1/26/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "symbolTable.h"


@implementation symbolTable
-(void) setTable:(NSMutableArray *) value;
{
	[table autorelease];
	table = [value copy];
}
-(NSMutableArray *) table
{
	return table;
}

// Searching and adding methods
-(int) checkConstant: (NSString *) token
{
	NSEnumerator *tokenEnum = [table objectEnumerator];
	symbols *symbolRow;
	int tokenValue = 0;
	BOOL keepGoing = YES;
	
	while ( keepGoing ) 
	{
		if ( symbolRow = [tokenEnum nextObject]) != nil) {
			if ( [[symbolRow tokenName] isEqualToString: token] ) {
				tokenValue = [symbolRow tokenType];
				keepGoing == NO;
			}
		} else {			
			symbolRow = [[symbols alloc] initWithString:rw];
			[workingElement setTokenType:101];
			keepGoing = NO;
		}
	}
	return tokenValue;
	
}

-(int) checkIdentifier: (NSString *) token
{
	NSEnumerator *tokenEnum = [table objectEnumerator];
	symbols *symbolRow;
	int tokenValue = 0;
	BOOL keepGoing = YES;
	
	while ( keepGoing ) 
	{
		if ( symbolRow = [tokenEnum nextObject]) != nil) {
			if ( [[symbolRow tokenName] isEqualToString: token] ) {
				tokenValue = [symbolRow tokenType];
				keepGoing == NO;
			}
		} else {			
			symbolRow = [[symbols alloc] initWithString:rw];
			[workingElement setTokenType:102];
			keepGoing = NO;
		}
	}
	return tokenValue;
	
}

// Initialize 

-(symbolTable *) initWithSet:(NSSet ) values
{
	NSEnumerator *rwEnum = [vales objectEnumerator]; 
	NSString *rw;
	table = [[NSMutableArray alloc] initWithCapacity:100];
	symbols *workingElement;
	int count = 1;
	while ( ( rw = [rwEnum nextObject ] )!= nil) 
	{
		NSAutoreleasePool *rwPool = [[NSAutoreleasePool alloc] init];
		workingElement = [[symbols alloc] initWithString:rw];
		[workingElement setTokenType:count++];
		[table addObject:workingElement];
		[workingElement autorelease];
		[rwPool release];
	}
	[rwEnum release];
	return self;
	
}


@end

//
//  quadUnit.m
//  semActions
//
//  Created by Daniel Beatty on 3/26/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "quadUnit.h"


@implementation quadUnit

-(int) op
{
	return op;
}

-(int) arg1
{
	return arg1;
}

-(int) arg2
{
	return arg2;
}

-(int) arg1Offset
{
	return arg1Offset;
}

-(int) arg2Offset
{
	return arg2Offset;
}

-(int) results
{
	return results;
}


-(int) resultsOffset
{
	return resultsOffset;
}



-(void) setOp:(int) value
{
	op = value;
}

-(void) setArg1:(int) value
{
	arg1 = value;
}

-(void) setArg2:(int) value
{
	arg2 = value;
}

-(void) results:(int) value
{
	results = value;
}

-(void) setArg1Offset:(int) value
{
	arg1Offset = value;
}

-(void) setArg2Offset:(int) value
{
	arg2Offset = value;
}


-(void) setResults:(int) value
{
	results = value;
}

-(void) setResultsOffset:(int) value
{
	resultsOffset = value;
}

-(id) init
{
	[super init];
	op = 0;
	arg1 = 0;
	arg2 = 0;
	results = 0;
	arg1Offset = 0; 
	arg2Offset = 0;
	resultsOffset = 0;
	
	
	return self;
}

-(void) dealloc
{
	[super dealloc];
}

@end
